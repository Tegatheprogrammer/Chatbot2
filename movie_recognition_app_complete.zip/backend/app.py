import os
import sys
from pathlib import Path

# Add the backend directory to Python path
backend_dir = Path(__file__).resolve().parent
sys.path.insert(0, str(backend_dir))

from flask import Flask
from flask_cors import CORS
from api.routes import api
from config.settings import DEBUG, PORT, HOST

app = Flask(__name__)
CORS(app, resources={
    r"/api/*": {
        "origins": ["http://localhost:8000"],
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type"]
    }
})

# Register blueprints
app.register_blueprint(api, url_prefix='/api')

if __name__ == '__main__':
    print(f"Starting server on http://{HOST}:{PORT}")
    app.run(debug=DEBUG, port=PORT, host=HOST)
