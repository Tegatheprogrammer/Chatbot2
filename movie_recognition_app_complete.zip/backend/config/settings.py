import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# API Keys and configuration
TMDB_API_KEY = os.getenv('TMDB_API_KEY')
RAPIDAPI_KEY = os.getenv('RAPIDAPI_KEY')
RAPIDAPI_HOST = os.getenv('RAPIDAPI_HOST')

# API URLs
TMDB_BASE_URL = 'https://api.themoviedb.org/3'
RAPIDAPI_BASE_URL = f'https://{RAPIDAPI_HOST}'

# Flask configuration
DEBUG = True
PORT = 5001
HOST = 'localhost'
