from flask import Blueprint, request, jsonify
import requests
import os
from .user_tracking import check_and_update_search_limits, get_user_limits

api = Blueprint('api', __name__)

def get_ai_recommendation(query):
    try:
        RAPIDAPI_KEY = os.getenv('RAPIDAPI_KEY')
        RAPIDAPI_HOST = os.getenv('RAPIDAPI_HOST', 'search-gpt.p.rapidapi.com')
        
        url = f"https://{RAPIDAPI_HOST}/"
        
        payload = {
            "model": "search-gpt-3.5-turbo",
            "messages": [{
                "role": "user",
                "content": f"Based on this description: '{query}', suggest 2-3 specific movie titles that best match it. Only include the movie titles, separated by commas. For example: 'The Matrix, Inception'"
            }]
        }
        
        headers = {
            'x-rapidapi-key': RAPIDAPI_KEY,
            'x-rapidapi-host': RAPIDAPI_HOST,
            'Content-Type': "application/json"
        }
        
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()
        
        suggestion = data['choices'][0]['message']['content']
        print(f"AI suggestion: {suggestion}")  # Debug log
        return suggestion
    
    except Exception as e:
        print(f"AI recommendation error: {str(e)}")
        return None

def search_movies(query, ai_suggestion=None):
    try:
        TMDB_API_KEY = os.getenv('TMDB_API_KEY')
        print(f"Using TMDB API key: {TMDB_API_KEY}")  # Debug log
        
        # First try searching with the original query
        url = f"https://api.themoviedb.org/3/search/movie"
        params = {
            'api_key': TMDB_API_KEY,
            'query': query
        }
        
        print(f"Making request to TMDB API with original query: {query}")
        response = requests.get(url, params=params)
        print(f"TMDB API Response status: {response.status_code}")
        
        response.raise_for_status()
        data = response.json()
        results = data.get('results', [])
        
        # If we got results, return them
        if results:
            print(f"Found {len(results)} movies with original query")
            return results
            
        # If no results and we have AI suggestions, try those
        if ai_suggestion:
            print(f"No results with original query, trying AI suggestions: {ai_suggestion}")
            all_results = []
            
            # Split the AI suggestions and search for each movie
            for movie_title in ai_suggestion.split(','):
                movie_title = movie_title.strip()
                if not movie_title:
                    continue
                    
                print(f"Searching for AI suggested movie: {movie_title}")
                params['query'] = movie_title
                response = requests.get(url, params=params)
                response.raise_for_status()
                data = response.json()
                results = data.get('results', [])
                
                if results:
                    # Add the first (most relevant) result
                    all_results.append(results[0])
            
            print(f"Found {len(all_results)} movies from AI suggestions")
            return all_results
            
        return []
        
    except Exception as e:
        print(f"Movie search error: {str(e)}")
        print(f"Full error details: {repr(e)}")
        return []

@api.route('/user/limits', methods=['GET'])
def get_limits():
    return jsonify(get_user_limits())

@api.route('/movies/search', methods=['POST'])
def search():
    try:
        data = request.json
        query = data.get('query')
        
        if not query:
            return jsonify({'error': 'No query provided'}), 400

        # Check user limits
        can_search, error_message, user_data = check_and_update_search_limits()
        if not can_search:
            return jsonify({
                'error': error_message,
                'limits': user_data
            }), 403

        # Get AI recommendations
        ai_suggestion = get_ai_recommendation(query)
        
        # Get movie results using both the query and AI suggestions
        movie_results = search_movies(query, ai_suggestion)
        
        # Return results
        return jsonify({
            'movies': movie_results,
            'ai_suggestion': f"Based on your description, you might be looking for: {ai_suggestion}",
            'limits': user_data
        })
        
    except Exception as e:
        print(f"Search error: {str(e)}")
        return jsonify({'error': 'An error occurred during search'}), 500
