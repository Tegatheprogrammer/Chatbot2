import json
import os
from datetime import datetime, timezone

# Constants
MAX_TOKENS = 5000
TOKENS_PER_SEARCH = 100
MAX_SEARCHES_PER_DAY = 50
USER_DATA_FILE = 'user_data.json'

def load_user_data():
    if os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, 'r') as f:
            return json.load(f)
    return {
        'total_tokens': MAX_TOKENS,
        'searches_today': 0,
        'last_search_date': None
    }

def save_user_data(data):
    with open(USER_DATA_FILE, 'w') as f:
        json.dump(data, f)

def check_and_update_search_limits():
    user_data = load_user_data()
    
    # Reset daily searches if it's a new day
    current_date = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    if user_data['last_search_date'] != current_date:
        user_data['searches_today'] = 0
        user_data['last_search_date'] = current_date
    
    # Check if user has enough tokens and hasn't exceeded daily search limit
    if user_data['total_tokens'] < TOKENS_PER_SEARCH:
        return False, 'Not enough tokens remaining', user_data
    
    if user_data['searches_today'] >= MAX_SEARCHES_PER_DAY:
        return False, 'Daily search limit exceeded', user_data
    
    # Update limits
    user_data['total_tokens'] -= TOKENS_PER_SEARCH
    user_data['searches_today'] += 1
    save_user_data(user_data)
    
    return True, None, user_data

def get_user_limits():
    user_data = load_user_data()
    return {
        'tokens_remaining': user_data['total_tokens'],
        'searches_remaining': MAX_SEARCHES_PER_DAY - user_data['searches_today']
    }
