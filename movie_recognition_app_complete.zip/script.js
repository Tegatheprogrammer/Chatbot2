// Wait for DOM to be fully loaded before running any code
document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements - support both search interfaces
    const searchInput = document.querySelector('.search-input') || document.getElementById('search-input');
    const searchForm = document.querySelector('.search-form');
    const searchButton = document.getElementById('search-button');
    const clearButton = document.getElementById('clear-search');
    const micButton = document.getElementById('mic-button');
    const stopListeningButton = document.getElementById('stop-listening');
    const searchResults = document.getElementById('search-results');
    const loadingSpinner = document.getElementById('loading-spinner');
    const errorMessage = document.getElementById('error-message');
    const listeningOverlay = document.getElementById('listening-overlay');
    
    // Get limit display elements
    const tokensRemaining = document.getElementById('tokens-remaining');
    const searchesRemaining = document.getElementById('searches-remaining');
    const tokensPerSearch = document.getElementById('tokens-per-search');

    // Hide the listening overlay initially
    if (listeningOverlay) {
        listeningOverlay.style.display = 'none';
    }

    // Function to toggle clear button visibility
    function toggleClearButton() {
        if (clearButton) {
            clearButton.classList.toggle('hidden', !searchInput.value);
        }
    }

    // Function to clear search
    function clearSearch() {
        if (searchInput) {
            searchInput.value = '';
            toggleClearButton();
            if (searchResults) {
                searchResults.innerHTML = '';
            }
            hideError();
        }
    }

    // Update limits display
    async function updateLimits() {
        try {
            const response = await fetch('http://127.0.0.1:5002/api/user/limits');
            if (!response.ok) throw new Error('Failed to fetch limits');
            
            const data = await response.json();
            if (tokensRemaining) tokensRemaining.textContent = data.tokens_remaining;
            if (searchesRemaining) searchesRemaining.textContent = data.searches_remaining;
            if (tokensPerSearch) tokensPerSearch.textContent = data.tokens_per_search;
        } catch (error) {
            console.error('Error fetching limits:', error);
        }
    }

    function showError(message) {
        console.log('Showing error:', message);
        if (errorMessage) {
            errorMessage.textContent = message;
            errorMessage.classList.remove('hidden');
        }
    }

    function hideError() {
        if (errorMessage) {
            errorMessage.classList.add('hidden');
        }
    }

    function showLoading() {
        if (loadingSpinner) {
            loadingSpinner.classList.remove('hidden');
        }
    }

    function hideLoading() {
        if (loadingSpinner) {
            loadingSpinner.classList.add('hidden');
        }
    }

    function createMovieCard(movie) {
        const movieCard = document.createElement('div');
        movieCard.className = 'movie-card';
        
        const posterUrl = movie.poster_path 
            ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
            : 'https://via.placeholder.com/500x750.png?text=No+Poster';
            
        const year = movie.release_date ? movie.release_date.split('-')[0] : 'N/A';
        const rating = movie.vote_average ? (movie.vote_average).toFixed(1) : 'N/A';
        
        movieCard.innerHTML = `
            <img src="${posterUrl}" alt="${movie.title}" class="movie-poster">
            <div class="movie-info">
                <h3 class="movie-title">${movie.title}</h3>
                <div class="movie-year">${year}</div>
                <p class="movie-overview">${movie.overview || 'No overview available'}</p>
                <div class="movie-rating">
                    <i class="fas fa-star"></i>
                    <span>${rating}</span>
                </div>
            </div>
        `;
        
        return movieCard;
    }

    function createAIRecommendation(suggestion) {
        const div = document.createElement('div');
        div.className = 'ai-suggestion';
        div.innerHTML = `
            <strong>AI Movie Suggestions</strong>
            ${suggestion}
        `;
        return div;
    }

    async function handleSearch(query) {
        console.log('Handling search for query:', query);
        if (!query) {
            showError('Please enter a search query');
            return;
        }

        hideError();
        showLoading();
        if (searchResults) {
            searchResults.innerHTML = '';
        }

        try {
            console.log('Making API request...');
            const response = await fetch('http://127.0.0.1:5002/api/movies/search', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query })
            });

            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Failed to search movies');
            }

            // Update limits if elements exist
            if (data.limits) {
                if (tokensRemaining) tokensRemaining.textContent = data.limits.tokens_remaining;
                if (searchesRemaining) searchesRemaining.textContent = data.limits.searches_remaining;
            }
            
            if (searchResults) {
                // Add AI suggestion if available
                if (data.ai_suggestion) {
                    searchResults.appendChild(createAIRecommendation(data.ai_suggestion));
                }
                
                // Add movie results
                if (data.movies && data.movies.length > 0) {
                    data.movies.forEach(movie => {
                        searchResults.appendChild(createMovieCard(movie));
                    });
                } else {
                    showError('No movies found matching your search');
                }
            }
        } catch (error) {
            console.error('Search error:', error);
            showError(error.message || 'An error occurred while searching');
        } finally {
            hideLoading();
        }
    }

    // Voice Recognition Setup
    let recognition = null;

    function startListening() {
        if (!recognition) {
            recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
            recognition.continuous = false;
            recognition.interimResults = false;

            recognition.onresult = function(event) {
                const transcript = event.results[0][0].transcript;
                if (searchInput) {
                    searchInput.value = transcript;
                    toggleClearButton();
                    handleSearch(transcript);
                }
            };

            recognition.onerror = function(event) {
                console.error('Speech recognition error:', event.error);
                showError('Failed to recognize speech. Please try again.');
            };

            recognition.onend = function() {
                stopListening();
            };
        }

        recognition.start();
        if (listeningOverlay) {
            listeningOverlay.style.display = 'flex';
        }
    }

    function stopListening() {
        if (recognition) {
            recognition.stop();
        }
        if (listeningOverlay) {
            listeningOverlay.style.display = 'none';
        }
    }

    // Add event listeners
    if (searchForm) {
        searchForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const query = searchInput.value.trim();
            await handleSearch(query);
        });
    }

    // Add click listener for search button
    if (searchButton) {
        searchButton.addEventListener('click', async () => {
            const query = searchInput.value.trim();
            await handleSearch(query);
        });
    }

    // Add input listener for search input to toggle clear button
    if (searchInput) {
        searchInput.addEventListener('input', toggleClearButton);
        
        // Add enter key support
        searchInput.addEventListener('keypress', async (e) => {
            if (e.key === 'Enter') {
                const query = searchInput.value.trim();
                await handleSearch(query);
            }
        });
    }

    // Add click listener for clear button
    if (clearButton) {
        clearButton.addEventListener('click', clearSearch);
    }

    if (micButton) {
        micButton.addEventListener('click', startListening);
    }

    if (stopListeningButton) {
        stopListeningButton.addEventListener('click', stopListening);
    }

    // Load initial limits
    updateLimits();
});