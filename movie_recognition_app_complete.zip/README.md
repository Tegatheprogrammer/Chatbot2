# Movie Finder Application

A modern web application that combines AI-powered movie suggestions with TMDB movie database search. Built with Flask backend and JavaScript frontend.

## Features
- 🎬 Search movies using natural language descriptions
- 🤖 AI-powered movie suggestions using GPT-3.5
- 🎯 Accurate movie search using TMDB database
- 💅 Beautiful, responsive UI with Tailwind CSS
- 🔒 Secure backend API handling

## Live Demo
[Add your deployed application URL here]

## Technologies Used
- **Frontend**: HTML5, CSS3 (Tailwind CSS), JavaScript
- **Backend**: Python, Flask
- **APIs**: TMDB API, RapidAPI Search GPT
- **Deployment**: Vercel (Frontend & Backend)

## Setup Instructions

### Step 1: Install Python
1. Download and install Python from [python.org](https://python.org)
2. Make sure Python is added to your system's PATH

### Step 2: Download the Files
1. Download all the files from this folder
2. Put them in a new folder on your computer

### Step 3: Install Required Packages
1. Open Terminal (Mac) or Command Prompt (Windows)
2. Navigate to the folder containing the files:
```bash
cd path/to/your/folder
```
3. Install the required packages:
```bash
pip install -r requirements.txt
```

### Step 4: Set up API Keys
1. Create a `.env` file in the folder
2. Add these lines to the file:
```env
TMDB_API_KEY=your_tmdb_api_key
RAPIDAPI_KEY=your_rapidapi_key
RAPIDAPI_HOST=search-gpt.p.rapidapi.com
```

### Step 5: Run the App
1. In Terminal/Command Prompt, run:
```bash
python app.py
```
2. Open `http://localhost:5000` in your web browser
3. Start searching for movies by describing them!

## Example Searches
Try these searches:
- "A movie about a father looking for his lost son in the ocean with a forgetful fish"
- "A movie where people enter dreams to plant ideas in someone's mind"
- "A movie about toys that come to life when humans aren't around"

## Troubleshooting
- If port 5000 is in use, edit `app.py` and change the port number to something else (e.g., 5003)
- Make sure all files are in the same folder
- Check that Python and all required packages are installed correctly

## Need Help?
If you run into any issues:
1. Make sure Python is installed and in your PATH
2. Verify all files are in the same folder
3. Check that the `.env` file exists and contains the API keys
4. Ensure all required packages are installed
5. Try restarting your computer if the port is in use

## Deployment Instructions

### Deploy to Vercel
1. Fork/Clone this repository
2. Create a new project on Vercel
3. Connect your GitHub repository
4. Add your environment variables in Vercel:
   - `TMDB_API_KEY`
   - `RAPIDAPI_KEY`
   - `RAPIDAPI_HOST`
5. Deploy!

### Alternative Deployment Options
You can also deploy to:
- Heroku
- DigitalOcean
- AWS
- Google Cloud Platform

## Project Structure
```
project/
├── backend/
│   ├── api/
│   │   ├── movie_service.py
│   │   └── routes.py
│   ├── config/
│   │   └── settings.py
│   └── app.py
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   ├── services/
│   │   └── styles/
│   ├── index.html
│   └── package.json
├── .env
├── requirements.txt
└── vercel.json
```

## Submission Checklist
- [ ] All code is properly commented and documented
- [ ] Environment variables are properly set up
- [ ] Application is tested and working in production
- [ ] README is complete with setup and deployment instructions
- [ ] All API keys are valid and active
- [ ] Frontend build is optimized for production
- [ ] Backend is properly configured for production
- [ ] Error handling is implemented
- [ ] Responsive design works on all devices

## Contributing
Feel free to submit issues and enhancement requests!

## License
This project is licensed under the MIT License - see the LICENSE file for details.
