import React, { useState } from 'react';
import { SearchBar } from './components/SearchBar';

interface MovieResult {
  id: number;
  title: string;
  overview: string;
  release_date: string;
  poster_path: string | null;
}

function App() {
  const [searchResults, setSearchResults] = useState<MovieResult[]>([]);

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto py-4 px-4">
          <h1 className="text-2xl font-bold text-gray-900">Movie Finder</h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <SearchBar onResults={setSearchResults} />
        
        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {searchResults.map((movie) => (
            <div key={movie.id} className="bg-white rounded-lg shadow-md overflow-hidden">
              {movie.poster_path && (
                <img
                  src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                  alt={movie.title}
                  className="w-full h-48 object-cover"
                />
              )}
              <div className="p-4">
                <h2 className="text-xl font-semibold mb-2">{movie.title}</h2>
                <p className="text-sm text-gray-600 mb-2">
                  Released: {new Date(movie.release_date).toLocaleDateString()}
                </p>
                <p className="text-gray-700 line-clamp-3">{movie.overview}</p>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;