import React, { useState } from 'react';
import { processNaturalLanguageQuery } from '../services/movieService';
import { Search, Mic, Loader2 } from 'lucide-react';

interface SearchBarProps {
  onResults: (results: any[]) => void;
}

export function SearchBar({ onResults }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!query.trim()) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const results = await processNaturalLanguageQuery(query);
      onResults(results);
      if (results.length === 0) {
        setError('No movies found matching your description. Try being more specific.');
      }
    } catch (error) {
      console.error('Search failed:', error);
      setError('Failed to search for movies. Please try again.');
      onResults([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="flex flex-col gap-2 max-w-2xl mx-auto p-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Describe the movie you're looking for..."
            className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={isLoading}
          />
          <button
            onClick={handleSearch}
            disabled={isLoading || !query.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-gray-500 hover:text-gray-700 disabled:opacity-50"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Search className="w-5 h-5" />
            )}
          </button>
        </div>
        <button
          className="p-2 rounded-full bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50"
          disabled={isLoading}
        >
          <Mic className="w-5 h-5" />
        </button>
      </div>
      {error && (
        <p className="text-red-500 text-sm mt-2">{error}</p>
      )}
    </div>
  );
}