import axios from 'axios';

const TMDB_API_KEY = 'b4f009f633383dd06923ff49450c59b1';
const SWIFT_AI_KEY = '70555fcaffmsh4d70f98f2a5e381p14dacejsnb9c9a49598f3';
const SWIFT_AI_HOST = 'swift-ai.p.rapidapi.com';

interface MovieSearchResponse {
  results: Array<{
    id: number;
    title: string;
    overview: string;
    release_date: string;
    poster_path: string | null;
  }>;
}

export async function processNaturalLanguageQuery(query: string) {
  try {
    // First, process the natural language query with Swift AI
    const aiResponse = await axios.post('https://swift-ai.p.rapidapi.com/chat/completions', {
      messages: [{
        role: 'user',
        content: `You are a movie search expert. Given this movie description: "${query}", provide the most likely movie title or key search terms. Keep it concise and focused on the main elements. For example, for "A movie about a boy wizard who goes to a magical school" respond with "Harry Potter".`
      }],
      model: 'gpt-3.5-turbo',
      max_tokens: 50,
      temperature: 0.7
    }, {
      headers: {
        'X-RapidAPI-Key': SWIFT_AI_KEY,
        'X-RapidAPI-Host': SWIFT_AI_HOST,
        'Content-Type': 'application/json'
      }
    });

    // Extract the search terms from the AI response
    const searchTerms = aiResponse.data.choices[0].message.content.trim();
    console.log('AI processed search terms:', searchTerms);

    // Try first with the AI-processed terms
    let tmdbResponse = await searchTMDB(searchTerms);
    
    // If no results, try with the original query as fallback
    if (tmdbResponse.data.results.length === 0) {
      console.log('No results with AI terms, trying original query:', query);
      tmdbResponse = await searchTMDB(query);
    }

    console.log('TMDB results:', tmdbResponse.data.results);
    return tmdbResponse.data.results;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error('API Error:', error.response?.data);
      throw new Error(error.response?.data?.message || 'Failed to process movie search');
    }
    throw error;
  }
}

async function searchTMDB(query: string) {
  return axios.get<MovieSearchResponse>(
    `https://api.themoviedb.org/3/search/movie`,
    {
      params: {
        api_key: TMDB_API_KEY,
        query: query,
        include_adult: false,
        language: 'en-US',
        page: 1
      }
    }
  );
}